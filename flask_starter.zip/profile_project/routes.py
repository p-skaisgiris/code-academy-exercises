from flask import render_template
from profile_project import app
from profile_project.models import User


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/profile/<username>")
def display_profile(username):
    user = User.query.filter_by(username=username).one()
    return render_template("profile.html", user=user)