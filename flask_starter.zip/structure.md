Ideal structure of a Flask application:

```bash
.
├── run.py                     # File for running the app (app.run)
└── students_flask             # Project module
    ├── forms.py               # Classes of forms (code similar to models.py)
    ├── __init__.py            # Flask configuration (app, db variables)
    ├── models.py              # Database models (code similar to forms.py)
    ├── routes.py              # Routes and their logic (rendering templates, sending data to templates and to DB)
    └── templates              # HMTL code renderd in browser; frontend
        ├── base.html          # Base HTML template which will be inherited by others, e.g. sharing the navbar
        └── index.html         # Code for the main website
```