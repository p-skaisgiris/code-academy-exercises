from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///week5.db"
db = SQLAlchemy(app)

# Give access to the application context for the database operations
app.app_context().push()

# Important! Keep this import at the end
from profile_project import routes
